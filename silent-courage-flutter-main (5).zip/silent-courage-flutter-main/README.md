# Silent Courage (নিরব সাহস)

A Flutter safety alert app that lets users silently send emergency messages, share location, and notify trusted contacts.

## Features
- Silent SOS alert button
- Easy to extend for location & SMS APIs
- Clean starter layout
